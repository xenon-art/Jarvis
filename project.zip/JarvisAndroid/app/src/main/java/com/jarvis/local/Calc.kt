package com.jarvis.local

import java.util.Locale

/** Small safe expression evaluator: + - * / ^ % and parentheses. */
object Calc {
    fun eval(src: String): Double {
        val s = src.replace("×", "*").replace("x", "*").replace("÷", "/")
            .replace(" ", "").replace(",", ".")
        val p = P(s)
        val v = p.expr()
        if (p.i != s.length) throw IllegalArgumentException("bad expression")
        return v
    }

    fun fmt(d: Double): String {
        if (d == Math.floor(d) && Math.abs(d) < 1e15) return d.toLong().toString()
        return String.format(Locale.US, "%.6f", d).trimEnd('0').trimEnd('.')
    }

    private class P(val s: String) {
        var i = 0
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        fun term(): Double {
            var v = pow()
            while (i < s.length && (s[i] == '*' || s[i] == '/' || s[i] == '%')) {
                val op = s[i++]
                val r = pow()
                v = when (op) {
                    '*' -> v * r
                    '/' -> v / r
                    else -> v % r
                }
            }
            return v
        }

        fun pow(): Double {
            val b = unary()
            if (i < s.length && s[i] == '^') {
                i++
                return Math.pow(b, pow())
            }
            return b
        }

        fun unary(): Double {
            if (i < s.length && s[i] == '-') { i++; return -unary() }
            if (i < s.length && s[i] == '+') { i++; return unary() }
            return primary()
        }

        fun primary(): Double {
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException("missing )")
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException("number expected")
            return s.substring(st, i).toDouble()
        }
    }
}
