package com.jarvis.local

import android.content.Context
import org.json.JSONObject

/**
 * The brain. Flow (inspired by OpenJarvis' agent + tool + approval design):
 *   1) pending confirmation / follow-up question?  2) fast rule router  3) on-device LLM chat
 * The LLM may also request a tool using <tool>{...}</tool>; sensitive tools still need user approval.
 */
class Assistant(
    private val ctx: Context,
    private val llm: LlmEngine,
    private val skills: Skills,
    private val ui: Ui,
    private val onMain: (() -> Unit) -> Unit
) {
    interface Ui {
        fun reply(text: String)
        fun confirm(prompt: String, yes: () -> Unit, no: () -> Unit)
        fun stream(text: String)
        fun streamEnd(finalText: String?)
        fun launchCamera(question: String)
        fun setLang(lang: String)
        fun stopSpeaking()
        fun busy(b: Boolean)
    }

    private class Pending(val run: () -> String)

    private var pending: Pending? = null
    private var ask: ((String) -> Outcome)? = null

    private val YES = Regex("""^(?:نعم|ايوه|ايوا|اجل|اكيد|تمام|ارسلها|ارسل|اتصل|كمل|اكمل|موافق|تاكيد|اكد|yes|yeah|yep|ok|okay|sure|confirm|send|send it|go|do it|go ahead)(?:\s+(?:نعم|ارسلها|ارسل|اتصل|تمام|please|من فضلك|الان|now))*$""")
    private val NO = Regex("""^(?:لا|كلا|الغ|الغي|الغاء|الغها|لا تفعل|لا ترسل|لا تتصل|توقف|وقف|no|nope|cancel|stop|don't|dont)$""")
    private val TOOL = Regex("""<tool>(.*?)</tool>""", RegexOption.DOT_MATCHES_ALL)

    fun systemPrompt(): String {
        val sb = StringBuilder(BASE_PROMPT)
        val notes = skills.memory.list()
        if (notes.isNotEmpty()) {
            sb.append("\nمعلومات أخبرك بها المستخدم (تذكّرها):\n")
            for (n in notes.takeLast(20)) sb.append("- ").append(n).append('\n')
        }
        return sb.toString()
    }

    fun handle(raw: String) {
        val input = raw.trim()
        if (input.isEmpty()) return
        val n = Norm(input).text.trim()

        val p = pending
        if (p != null) {
            if (YES.matches(n)) { answer(true); return }
            if (NO.matches(n)) { answer(false); return }
            pending = null
        }
        val a = ask
        if (a != null) {
            ask = null
            if (NO.matches(n)) { ui.reply("تم الإلغاء."); return }
            dispatch(a(input))
            return
        }
        val call = Router.route(input)
        if (call != null) {
            dispatch(skills.run(call))
            return
        }
        chat(input, null)
    }

    fun answer(yes: Boolean) {
        val p = pending ?: return
        pending = null
        if (yes) ui.reply(p.run()) else ui.reply("تم الإلغاء.")
    }

    private fun dispatch(o: Outcome) {
        when (o) {
            is Outcome.Say -> ui.reply(o.text)
            is Outcome.Confirm -> {
                pending = Pending(o.run)
                ui.confirm(o.prompt, { answer(true) }, { answer(false) })
            }
            is Outcome.Ask -> {
                ask = o.next
                ui.reply(o.prompt)
            }
            is Outcome.Look -> {
                if (!llm.ready) ui.reply("حمّل النموذج أولًا من الإعدادات.")
                else if (!llm.vision) ui.reply("النموذج الحالي لا يدعم الصور. استخدم نموذج Gemma 4 أو Gemma 3n وفعّل خيار الصور في الإعدادات.")
                else ui.launchCamera(o.question)
            }
            is Outcome.SetLang -> {
                ui.setLang(o.lang)
                ui.reply(if (o.lang == "en") "Okay, I will speak English." else "حسنًا، سأتكلم بالعربية.")
            }
            Outcome.Silence -> ui.stopSpeaking()
        }
    }

    /** Called after the camera returns a photo. */
    fun look(question: String, imagePath: String) {
        chat(question.ifBlank { "صف ما تراه في الصورة بإيجاز." }, imagePath)
    }

    private fun chat(input: String, imagePath: String?) {
        if (!llm.ready) {
            ui.reply(
                if (llm.loading) "النموذج قيد التحميل، لحظة من فضلك."
                else "لم يتم تحميل نموذج الذكاء الاصطناعي بعد. افتح الإعدادات ⚙ ونزّل النموذج مرة واحدة، وبعدها أعمل دون إنترنت. الأوامر السريعة مثل الاتصال والمنبه تعمل بدونه."
            )
            return
        }
        if (llm.busy) {
            ui.reply("ما زلت أفكر في الطلب السابق.")
            return
        }
        llm.setSystem(systemPrompt())
        ui.busy(true)
        ui.stream("…")
        llm.ask(input, imagePath, { partial ->
            onMain { ui.stream(if (partial.trimStart().startsWith("<")) "…" else partial) }
        }) { full, err ->
            onMain {
                ui.busy(false)
                if (err != null || full == null) {
                    ui.streamEnd(null)
                    ui.reply("حدث خطأ في النموذج: ${err?.message ?: "غير معروف"}")
                } else {
                    handleModelOutput(full)
                }
            }
        }
    }

    private fun handleModelOutput(full: String) {
        val m = TOOL.find(full)
        if (m != null) {
            try {
                val j = JSONObject(m.groupValues[1].trim())
                val name = j.getString("name")
                val args = j.optJSONObject("args") ?: JSONObject()
                ui.streamEnd(null)
                dispatch(skills.run(ToolCall(name, args)))
                return
            } catch (e: Exception) {
                // fall through and show the text without the tag
            }
        }
        val clean = full.replace(TOOL, "").trim()
        ui.streamEnd(if (clean.isEmpty()) "تمام." else clean)
    }

    companion object {
        private val BASE_PROMPT = """
أنت «جارفس»: مساعد شخصي ذكي يعمل بالكامل داخل هاتف المستخدم وبدون إنترنت. أنت مخلص وهادئ وفعّال ودود وخفيف الظل بلا مبالغة.
You are Jarvis, a loyal, calm, efficient and warm on-device assistant.

القواعد:
- أجب بلغة المستخدم (العربية افتراضيًا). اجعل الرد قصيرًا: جملة إلى ثلاث جمل.
- ردودك تُقرأ بصوت عالٍ: لا تستخدم Markdown ولا رموزًا تعبيرية ولا قوائم برموز ولا جداول.
- كن صادقًا. إذا لم تعرف أو لم تستطع فقل ذلك. لا تخترع معلومات أو أسماء أو أرقامًا أو نتائج.
- ليس لديك إنترنت، فلا تدّعِ أنك تبحث أو تتصفح.
- لتنفيذ أمر على الهاتف أجب بسطر واحد فقط بهذه الصيغة ولا شيء غيره:
<tool>{"name":"TOOL_NAME","args":{}}</tool>
الأدوات:
send_message {to, text, channel: "sms" أو "whatsapp"} إرسال رسالة لجهة اتصال
call {to} اتصال بجهة اتصال
open_app {name} فتح تطبيق
set_alarm {hour: 0-23, minute, label} منبه
set_timer {seconds, label} مؤقت أو تذكير بعد مدة
flashlight {on: true أو false} الكشاف
remember {text} حفظ معلومة عن المستخدم
battery {} نسبة البطارية
time {kind: "time" أو "date"} الوقت أو التاريخ
- استخدم الأداة فقط عندما يطلب المستخدم ذلك بوضوح. الأوامر الحساسة يؤكدها المستخدم قبل التنفيذ.
""".trimIndent()
    }
}
