package com.jarvis.local

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Offline-first voice: system SpeechRecognizer (prefer offline) + system TextToSpeech. All callbacks on the main thread. */
class Voice(
    private val ctx: Context,
    private val onFinal: (String) -> Unit,
    private val onPartial: (String) -> Unit,
    private val onListening: (Boolean) -> Unit,
    private val onProblem: (String) -> Unit,
    private val onSpoken: () -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsOk = false

    var listening = false
        private set

    var lang: String = "ar"
        set(v) {
            field = v
            applyTtsLang()
        }

    fun init() {
        tts = TextToSpeech(ctx) { status ->
            ttsOk = status == TextToSpeech.SUCCESS
            if (ttsOk) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        main.post { onSpoken() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        main.post { onSpoken() }
                    }
                })
                main.post { applyTtsLang() }
            }
        }
    }

    private fun applyTtsLang() {
        val t = tts ?: return
        if (!ttsOk) return
        val loc = if (lang == "ar") Locale.forLanguageTag("ar") else Locale.US
        val r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            onProblem(
                if (lang == "ar") "صوت اللغة العربية غير مثبّت. ثبّته من إعدادات الهاتف ← تحويل النص إلى كلام."
                else "English voice is not installed on this phone."
            )
        }
    }

    fun speak(text: String) {
        val t = tts
        if (t == null || !ttsOk) {
            main.post { onSpoken() }
            return
        }
        val clean = text.replace(Regex("[*_#`>~]"), "").replace(Regex("<[^>]+>"), "").take(3500).trim()
        if (clean.isEmpty()) {
            main.post { onSpoken() }
            return
        }
        t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "j" + System.nanoTime())
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            listening = false
            onListening(false)
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {}
                SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
                SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE ->
                    onProblem("لغة التعرف على الصوت غير متوفرة دون إنترنت. نزّل الحزمة: إعدادات Google ← الصوت ← التعرف على الكلام دون اتصال.")
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    onProblem("أحتاج صلاحية الميكروفون.")
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER ->
                    onProblem("التعرف على الصوت يحتاج حزمة لغة محمّلة للعمل دون إنترنت. نزّلها من إعدادات Google ← الصوت.")
                else -> onProblem("تعذّر التعرف على الصوت (رمز ${error}).")
            }
        }

        override fun onResults(results: Bundle?) {
            listening = false
            onListening(false)
            val s = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!s.isNullOrBlank()) onFinal(s)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val s = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!s.isNullOrBlank()) onPartial(s)
        }
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onProblem("خدمة التعرف على الصوت غير متوفرة على هذا الهاتف.")
            return
        }
        stopSpeaking()
        var r = rec
        if (r == null) {
            r = SpeechRecognizer.createSpeechRecognizer(ctx)
            r.setRecognitionListener(listener)
            rec = r
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (lang == "ar") "ar-SA" else "en-US")
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        listening = true
        onListening(true)
        r.startListening(i)
    }

    fun stopListening() {
        rec?.cancel()
        listening = false
        onListening(false)
    }

    fun destroy() {
        try {
            rec?.destroy()
        } catch (e: Exception) {
        }
        tts?.stop()
        tts?.shutdown()
    }
}
