package com.jarvis.local

import org.json.JSONObject
import java.util.Calendar

data class ToolCall(val name: String, val args: JSONObject = JSONObject())

/**
 * Fast rule-based command router (Arabic + English). Common phone commands are
 * handled here instantly and reliably, without waiting for the language model.
 * Anything unmatched goes to the model as normal chat.
 */
object Router {
    private val PREFIX = Regex("""^(?:(?:يا\s+)?(?:جارفس|جارفيس|جرفس|jarvis|hey jarvis)|من فضلك|لو سمحت|please|ممكن|اريدك ان|اريد ان|اريد|ابغا|ابغي|ابي|عايز|بدي|لو تكرمت)(?:[\s,:]+|$)""")

    fun route(input: String): ToolCall? {
        val n = Norm(input)
        var base = 0
        while (true) {
            val m = PREFIX.find(n.text.substring(base)) ?: break
            base += m.range.last + 1
        }
        val rest0 = n.text.substring(base)
        base += rest0.length - rest0.trimStart().length
        val t = n.text.substring(base).trimEnd()
        if (t.isEmpty()) return null
        return stop(t) ?: lang(t) ?: timeQ(t) ?: battery(t) ?: flash(t) ?: memory(t, n, base)
            ?: timer(t, input) ?: calc(t) ?: callQ(t) ?: sendMsg(n, base, t) ?: openApp(t) ?: look(t, input)
    }

    private fun stop(t: String): ToolCall? =
        if (Regex("""^(?:اسكت|اسكتي|توقف|كفايه|بس|stop|quiet|shut up)$""").matches(t)) ToolCall("stop") else null

    private fun lang(t: String): ToolCall? {
        if (Regex("""(?:تكلم|تحدث|اتكلم|speak|talk)\s+(?:ب|باللغه\s+)?(?:ال)?(?:انجليزي|انجليزيه|english)""").containsMatchIn(t))
            return ToolCall("set_lang", JSONObject().put("lang", "en"))
        if (Regex("""(?:تكلم|تحدث|اتكلم|speak|talk)\s+(?:ب|باللغه\s+)?(?:ال)?(?:عربي|عربيه|arabic)""").containsMatchIn(t))
            return ToolCall("set_lang", JSONObject().put("lang", "ar"))
        return null
    }

    private fun timeQ(t: String): ToolCall? {
        if (Regex("""(?:كم الساعه|الساعه كم|الساعه الان|ما الوقت|الوقت الان|كم الوقت|what time|time now|current time|time is it)""").containsMatchIn(t))
            return ToolCall("time", JSONObject().put("kind", "time"))
        if (Regex("""(?:التاريخ|اي يوم|ما اليوم|اليوم كم|what day|date today|today's date|the date)""").containsMatchIn(t))
            return ToolCall("time", JSONObject().put("kind", "date"))
        return null
    }

    private fun battery(t: String): ToolCall? =
        if (Regex("""(?:البطاريه|battery|نسبه الشحن)""").containsMatchIn(t)) ToolCall("battery") else null

    private fun flash(t: String): ToolCall? {
        if (!Regex("""(?:كشاف|فلاش|المصباح|flashlight|torch)""").containsMatchIn(t)) return null
        val off = Regex("""(?:اطفي|اطفاء|اقفل|اغلق|وقف|off)""").containsMatchIn(t)
        return ToolCall("flashlight", JSONObject().put("on", !off))
    }

    private fun memory(t: String, n: Norm, base: Int): ToolCall? {
        if (Regex("""(?:ماذا تتذكر|ايش تتذكر|شو تتذكر|وش تتذكر|ماذا حفظت|ملاحظاتي|what do you remember|my notes|what did i tell you)""").containsMatchIn(t))
            return ToolCall("recall")
        if (Regex("""(?:انسي كل|امسح (?:كل )?(?:الملاحظات|الذاكره|ذاكرتك)|forget everything|clear (?:my )?(?:notes|memory))""").containsMatchIn(t))
            return ToolCall("forget")
        val m = Regex("""^(?:تذكر|تذكري|احفظ|سجل|دون|remember|note down|note)\s+(?:ان\s+|that\s+)?(.+)$""").find(t) ?: return null
        val g = m.groups[1] ?: return null
        val text = n.orig(base + g.range.first, base + g.range.last + 1)
        return ToolCall("remember", JSONObject().put("text", text))
    }

    // ---------- timers & alarms ----------
    private val DUR = Regex("""(\d+(?:\.\d+)?)\s*(ثانيه|ثواني|sec(?:ond)?s?|دقيقه|دقايق|minutes?|mins?|ساعه|ساعات|hours?|hrs?)""")
    private val TIMER_KW = Regex("""(?:موقت|عداد|تايمر|timer|ذكرني|ذكريني|remind|نبهني|نبهيني|صحيني|ايقظني|wake me|منبه|alarm)""")
    private val ALARM_KW = Regex("""(?:منبه|alarm|نبهني|نبهيني|صحيني|ايقظني|wake me|ذكرني|ذكريني|remind me)""")
    private val ABS = Regex("""(?:الساعه|ساعه|at|عند)?\s*(\d{1,2})(?:[:.](\d{2}))?\s*(ونص|ونصف|وربع|وثلث|الا ربع)?\s*(صباحا|الصباح|صباح|فجرا|الفجر|ظهرا|الظهر|عصرا|العصر|مساء|المساء|ليلا|الليل|am|pm|ص|م)?(?=\s|$)""")

    private fun durationSeconds(t: String): Int? {
        if (Regex("""(?:نص|نصف)\s+ساعه""").containsMatchIn(t)) return 1800
        if (Regex("""ربع\s+ساعه""").containsMatchIn(t)) return 900
        if (Regex("""ساعه\s+و\s*(?:نص|نصف)""").containsMatchIn(t)) return 5400
        if (t.contains("دقيقتين")) return 120
        if (t.contains("ساعتين")) return 7200
        val m = DUR.find(t) ?: return null
        val v = m.groupValues[1].toDouble()
        val u = m.groupValues[2]
        val mul = when {
            u.startsWith("ثان") || u.startsWith("sec") -> 1
            u.startsWith("دقي") || u.startsWith("دقا") || u.startsWith("min") -> 60
            else -> 3600
        }
        return (v * mul).toInt()
    }

    private fun timer(t: String, orig: String): ToolCall? {
        val secs = durationSeconds(t)
        if (secs != null && secs > 0 && TIMER_KW.containsMatchIn(t)) {
            return ToolCall("set_timer", JSONObject().put("seconds", secs).put("label", orig.take(40)))
        }
        if (!ALARM_KW.containsMatchIn(t)) return null
        val m = ABS.find(t) ?: return null
        var h = m.groupValues[1].toIntOrNull() ?: return null
        var min = m.groupValues[2].toIntOrNull() ?: 0
        val extra = m.groupValues[3]
        val marker = m.groupValues[4]
        if (h > 24 || min > 59) return null
        when (extra) {
            "ونص", "ونصف" -> min = 30
            "وربع" -> min = 15
            "وثلث" -> min = 20
            "الا ربع" -> { h = if (h == 0) 23 else h - 1; min = 45 }
        }
        h = resolveHour(h, min, marker)
        return ToolCall("set_alarm", JSONObject().put("hour", h).put("minute", min).put("label", "Jarvis"))
    }

    private fun resolveHour(h: Int, min: Int, marker: String): Int {
        val pm = marker in listOf("مساء", "المساء", "ليلا", "الليل", "م", "pm", "عصرا", "العصر")
        val am = marker in listOf("صباحا", "الصباح", "صباح", "فجرا", "الفجر", "ص", "am")
        val noon = marker in listOf("ظهرا", "الظهر")
        if (h > 12) return h % 24
        if (pm) return if (h == 12) 12 else h + 12
        if (am) return if (h == 12) 0 else h
        if (noon) return if (h < 6) h + 12 else h
        // no marker: choose the nearest upcoming occurrence (AM or PM)
        val now = Calendar.getInstance()
        val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        var best = h % 12
        var bestDiff = Int.MAX_VALUE
        for (c in listOf(h % 12, h % 12 + 12)) {
            val diff = ((c * 60 + min) - nowMin + 1440) % 1440
            if (diff in 1 until bestDiff) { bestDiff = diff; best = c }
        }
        return best
    }

    private fun calc(t: String): ToolCall? {
        val m = Regex("""^(?:احسب|كم يساوي|ما ناتج|ناتج|calculate|calc|what is|whats|what's)?\s*([0-9+\-*/x×÷().,^% ]+)$""").find(t) ?: return null
        val expr = m.groupValues[1].trim()
        if (!expr.any { it.isDigit() } || !expr.any { it in "+-*/x×÷^%" }) return null
        return ToolCall("calc", JSONObject().put("expr", expr))
    }

    private fun callQ(t: String): ToolCall? {
        val m = Regex("""^(?:اتصل|اتصلي|كلم|كلمي|call|phone|dial|رن)\s+(?:علي\s+|to\s+)?(.+)$""").find(t) ?: return null
        return ToolCall("call", JSONObject().put("to", m.groupValues[1].trim()))
    }

    // ---------- messages ----------
    private val SEND_VERB = Regex("""^(ارسل|ارسلي|ابعث|ابعثي|بعث|اكتب|ارسال|send|text|message|whatsapp|واتساب)\s+(.*)$""")
    private val FILLER = Regex("""^(?:رساله|رسايل|message|msg|sms|text|بالواتساب|بالواتس اب|بواتساب|واتساب|واتس اب|واتس|whatsapp|عبر|بواسطه)\s+""")
    private val MARK = Regex("""(?:\s+(?:تقول(?:\s+(?:له|لها))?|يقول|بنص|نصها|نصه|مفادها|وقل(?:\s+(?:له|لها))?|قل(?:\s+(?:له|لها))?|that says|saying that|saying|says|say)(?=\s|$)|\s*:)\s*""")
    private val MSG_WORD = Regex("""(?:رساله|رسايل|message|msg|sms|واتس|whatsapp)""")
    private val MSG_WORD_CUT = Regex("""\s+(?:رساله|رسايل|message|msg|sms|text|بالواتساب|واتساب|واتس اب|whatsapp)(?=\s|$)""")
    private val MSG_WORD_ORIG = Regex("""(?:^|\s)(?:رسال[ةه]|رسايل|message|msg|sms)(?=\s|$)""", RegexOption.IGNORE_CASE)

    private fun sendMsg(n: Norm, base: Int, t: String): ToolCall? {
        val m = SEND_VERB.find(t) ?: return null
        val verb = m.groupValues[1]
        val hasMsgWord = MSG_WORD.containsMatchIn(t)
        if ((verb == "اكتب" || verb == "text" || verb == "message") && !hasMsgWord) return null
        val channel = if (t.contains("واتس") || t.contains("whatsapp")) "whatsapp" else "sms"
        var pos = m.groups[2]!!.range.first
        while (true) {
            val f = FILLER.find(t.substring(pos)) ?: break
            pos += f.range.last + 1
        }
        val rest = t.substring(pos)
        val args = JSONObject().put("channel", channel)
        val mk = MARK.find(rest)
        if (mk != null) {
            var rec = rest.substring(0, mk.range.first).trim()
            val cut = MSG_WORD_CUT.find(" $rec")
            if (cut != null) rec = (" $rec").substring(0, cut.range.first).trim()
            val body = n.orig(base + pos + mk.range.last + 1, n.text.length).trim()
            args.put("to", rec).put("text", body)
        } else {
            val rawOrig = n.orig(base + pos, n.text.length)
            val raw = rawOrig.replace(MSG_WORD_ORIG, " ").trim()
            args.put("raw", raw)
        }
        return ToolCall("send_message", args)
    }

    private fun openApp(t: String): ToolCall? {
        val m = Regex("""^(?:افتح|افتحي|شغل|شغلي|open|launch|start|run)\s+(?:تطبيق\s+|برنامج\s+|app\s+)?(.+)$""").find(t) ?: return null
        return ToolCall("open_app", JSONObject().put("name", m.groupValues[1].trim()))
    }

    private fun look(t: String, orig: String): ToolCall? {
        val a = Regex("""^(?:ما هذا|ما هذه|ايش هذا|شو هذا|وش هذا|what is this|what is that)(?:\s+(?:الشي|الشيء|الغرض|الجهاز|النبات|الحيوان|المكتوب))?\s*$""").containsMatchIn(t)
        val b = Regex("""(?:ماذا ترى|ما الذي ترى|what do you see|look at this|describe this|read this|اقرا هذا)""").containsMatchIn(t)
        val c = Regex("""^(?:صور|صوري|التقط|خذ صوره)""").containsMatchIn(t)
        if (!(a || b || c)) return null
        val q = if (c) "صف ما تراه في الصورة بإيجاز." else orig
        return ToolCall("look", JSONObject().put("question", q))
    }
}
