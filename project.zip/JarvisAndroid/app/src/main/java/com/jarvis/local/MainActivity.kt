package com.jarvis.local

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity(), Assistant.Ui {
    companion object {
        const val REQ_CAM = 11
        const val REQ_PICK = 12
        const val REQ_PERM = 13
        const val REQ_MIC = 14
    }

    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var micBtn: Button
    private lateinit var langBtn: Button
    private lateinit var contBtn: Button
    private lateinit var voice: Voice
    private lateinit var llm: LlmEngine
    private lateinit var assistant: Assistant
    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())

    private var streamView: TextView? = null
    private var confirmRow: View? = null
    private var continuous = false
    private var pendingQuestion = ""
    private var baseStatus = ""
    private var downloading = false
    private val hintText = "اكتب أو تكلّم…"

    private var dlgStatus: TextView? = null
    private var dlgBar: ProgressBar? = null

    // ------------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        prefs = getSharedPreferences("jarvis_ui", MODE_PRIVATE)
        buildUi()

        llm = LlmEngine(applicationContext)
        val skills = Skills(applicationContext, Memory(applicationContext))
        assistant = Assistant(applicationContext, llm, skills, this) { r -> runOnUiThread { r() } }

        voice = Voice(
            this,
            onFinal = { text -> input.hint = hintText; submit(text) },
            onPartial = { p -> input.hint = p },
            onListening = { on ->
                micBtn.text = if (on) "⏹" else "🎤"
                micBtn.background = bg(Color.parseColor(if (on) "#DC2626" else "#334155"), 24)
            },
            onProblem = { msg -> addAssistant(msg) },
            onSpoken = { if (continuous && !voice.listening && !llm.busy) voice.startListening() }
        )
        voice.lang = prefs.getString("lang", "ar") ?: "ar"
        voice.init()
        langBtn.text = if (voice.lang == "ar") "ع" else "EN"

        requestAllPermissions()
        addAssistant("أهلًا، أنا جارفس. اكتب أو اضغط 🎤 وتكلّم. جرّب: «أرسل لأمي رسالة تقول وصلت بالسلامة» أو «ضع منبه الساعة 7 صباحًا».")
        loadModelIfAny()
    }

    override fun onPause() {
        super.onPause()
        voice.stopListening()
    }

    override fun onDestroy() {
        super.onDestroy()
        voice.destroy()
        llm.close()
    }

    // ------------------------------------------------------------------ UI building
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        return g
    }

    private fun roundBtn(label: String, color: String): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 18f
        b.setTextColor(Color.WHITE)
        b.background = bg(Color.parseColor(color), 24)
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(dp(12), 0, dp(12), 0)
        return b
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0B1220"))
        root.setOnApplyWindowInsetsListener { v, insets ->
            val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsets.CONSUMED
        }

        // header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(14), dp(10), dp(10), dp(6))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = "Jarvis"
        title.textSize = 22f
        title.setTextColor(Color.parseColor("#38BDF8"))
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        status = TextView(this)
        status.textSize = 12f
        status.setTextColor(Color.parseColor("#94A3B8"))
        titles.addView(title)
        titles.addView(status)
        header.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        contBtn = roundBtn("🎧", "#334155")
        contBtn.setOnClickListener {
            continuous = !continuous
            contBtn.background = bg(Color.parseColor(if (continuous) "#16A34A" else "#334155"), 24)
            if (continuous) voice.startListening() else voice.stopListening()
        }
        langBtn = roundBtn("ع", "#334155")
        langBtn.setOnClickListener {
            val l = if (voice.lang == "ar") "en" else "ar"
            setLang(l)
        }
        val setBtn = roundBtn("⚙", "#334155")
        setBtn.setOnClickListener { showSetup() }
        val bw = LinearLayout.LayoutParams(dp(48), dp(42))
        bw.setMargins(dp(4), 0, 0, 0)
        header.addView(contBtn, bw)
        header.addView(langBtn, LinearLayout.LayoutParams(bw))
        header.addView(setBtn, LinearLayout.LayoutParams(bw))
        root.addView(header)

        // chat
        scroll = ScrollView(this)
        chat = LinearLayout(this)
        chat.orientation = LinearLayout.VERTICAL
        chat.setPadding(dp(12), dp(8), dp(12), dp(8))
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // input row
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(6), dp(10), dp(10))
        input = EditText(this)
        input.hint = hintText
        input.setHintTextColor(Color.parseColor("#64748B"))
        input.setTextColor(Color.WHITE)
        input.textSize = 16f
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.maxLines = 3
        input.background = bg(Color.parseColor("#1E293B"), 24)
        input.setPadding(dp(16), dp(10), dp(16), dp(10))
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                val t = input.text.toString()
                input.setText("")
                submit(t)
                true
            } else false
        }
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val cam = roundBtn("📷", "#334155")
        cam.setOnClickListener { launchCamera("") }
        micBtn = roundBtn("🎤", "#334155")
        micBtn.setOnClickListener {
            if (voice.listening) {
                voice.stopListening()
            } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            } else {
                voice.startListening()
            }
        }
        val send = roundBtn("➤", "#2563EB")
        send.setOnClickListener {
            val t = input.text.toString()
            input.setText("")
            submit(t)
        }
        val w = LinearLayout.LayoutParams(dp(48), dp(46))
        w.setMargins(dp(6), 0, 0, 0)
        row.addView(cam, w)
        row.addView(micBtn, LinearLayout.LayoutParams(w))
        row.addView(send, LinearLayout.LayoutParams(w))
        root.addView(row)

        setContentView(root)
    }

    private fun scrollDown() {
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun bubble(text: String, user: Boolean): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 16f
        tv.setTextColor(Color.parseColor(if (user) "#FFFFFF" else "#E2E8F0"))
        tv.setPadding(dp(14), dp(10), dp(14), dp(10))
        tv.background = bg(Color.parseColor(if (user) "#2563EB" else "#1E293B"), 18)
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.82f).toInt()
        tv.textAlignment = View.TEXT_ALIGNMENT_TEXT_START
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = if (user) Gravity.END else Gravity.START
        lp.setMargins(0, dp(4), 0, dp(4))
        chat.addView(tv, lp)
        scrollDown()
        return tv
    }

    private fun addUser(text: String) {
        confirmRow?.let { chat.removeView(it) }
        confirmRow = null
        bubble(text, true)
    }

    private fun addAssistant(text: String) {
        bubble(text, false)
    }

    private fun setStatus(s: String) {
        baseStatus = s
        status.text = s
    }

    private fun submit(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        addUser(t)
        assistant.handle(t)
    }

    // ------------------------------------------------------------------ Assistant.Ui
    override fun reply(text: String) {
        addAssistant(text)
        voice.speak(text)
    }

    override fun confirm(prompt: String, yes: () -> Unit, no: () -> Unit) {
        addAssistant(prompt)
        voice.speak(prompt)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun mk(label: String, color: String, act: () -> Unit): Button {
            val b = Button(this)
            b.text = label
            b.isAllCaps = false
            b.setTextColor(Color.WHITE)
            b.background = bg(Color.parseColor(color), 20)
            b.setOnClickListener {
                chat.removeView(row)
                confirmRow = null
                act()
            }
            return b
        }
        val p = LinearLayout.LayoutParams(0, dp(46), 1f)
        p.setMargins(dp(4), dp(2), dp(4), dp(2))
        row.addView(mk("✅ تأكيد", "#16A34A", yes), p)
        row.addView(mk("❌ إلغاء", "#DC2626", no), LinearLayout.LayoutParams(p))
        chat.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        confirmRow = row
        scrollDown()
    }

    override fun stream(text: String) {
        var v = streamView
        if (v == null) {
            v = bubble(text, false)
            streamView = v
        } else {
            v.text = text
        }
        scrollDown()
    }

    override fun streamEnd(finalText: String?) {
        val v = streamView
        streamView = null
        if (finalText == null) {
            if (v != null) chat.removeView(v)
        } else {
            if (v != null) v.text = finalText else addAssistant(finalText)
            voice.speak(finalText)
        }
        scrollDown()
    }

    override fun setLang(lang: String) {
        voice.lang = lang
        prefs.edit().putString("lang", lang).apply()
        langBtn.text = if (lang == "ar") "ع" else "EN"
    }

    override fun stopSpeaking() {
        voice.stopSpeaking()
    }

    override fun busy(b: Boolean) {
        status.text = if (b) "💭 أفكر…" else baseStatus
    }

    // ------------------------------------------------------------------ permissions
    private fun requestAllPermissions() {
        val perms = listOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        val need = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), REQ_PERM)
    }

    // ------------------------------------------------------------------ camera
    override fun launchCamera(question: String) {
        pendingQuestion = question
        if (!llm.ready || !llm.vision) {
            addAssistant("الكاميرا تحتاج نموذجًا يدعم الصور (مثل Gemma 4) محمّلًا مع تفعيل خيار الصور في الإعدادات ⚙.")
            return
        }
        try {
            val f = File(cacheDir, "shot.jpg")
            if (f.exists()) f.delete()
            val uri = FileProvider.getUriForFile(this, "${packageName}.files", f)
            val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            i.putExtra(MediaStore.EXTRA_OUTPUT, uri)
            i.clipData = ClipData.newRawUri("", uri)
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivityForResult(i, REQ_CAM)
        } catch (e: Exception) {
            addAssistant("تعذّر فتح الكاميرا: ${e.message}")
        }
    }

    private fun prepareImage(src: File): File? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(src.path, o)
        var s = 1
        while (o.outWidth / s > 1600 || o.outHeight / s > 1600) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        var bmp = BitmapFactory.decodeFile(src.path, o2) ?: return null
        val rot = when (ExifInterface(src.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
            6 -> 90f
            3 -> 180f
            8 -> 270f
            else -> 0f
        }
        if (rot != 0f) {
            val m = Matrix()
            m.postRotate(rot)
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val maxSide = 896
        val k = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
        if (k < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true)
        val out = File(cacheDir, "vision.jpg")
        FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        return out
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAM && resultCode == RESULT_OK) {
            val q = pendingQuestion
            Thread {
                val img = try {
                    prepareImage(File(cacheDir, "shot.jpg"))
                } catch (e: Exception) {
                    null
                }
                runOnUiThread {
                    if (img == null) {
                        addAssistant("تعذّر قراءة الصورة.")
                    } else {
                        val iv = ImageView(this)
                        iv.setImageBitmap(BitmapFactory.decodeFile(img.path, BitmapFactory.Options().also { it.inSampleSize = 4 }))
                        val lp = LinearLayout.LayoutParams(dp(160), dp(160))
                        lp.gravity = Gravity.END
                        iv.scaleType = ImageView.ScaleType.CENTER_CROP
                        chat.addView(iv, lp)
                        scrollDown()
                        assistant.look(q, img.path)
                    }
                }
            }.start()
        } else if (requestCode == REQ_PICK && resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!
            setDlg("⏳ جارٍ نسخ النموذج…")
            ModelStore.importUri(applicationContext, uri,
                { d, t -> runOnUiThread { progress(d, t) } },
                { f, err -> runOnUiThread { modelReady(f, err) } })
        }
    }

    // ------------------------------------------------------------------ model setup
    private fun setDlg(s: String) {
        dlgStatus?.text = s
    }

    private fun progress(done: Long, total: Long) {
        val mb = done / 1048576
        if (total > 0) {
            dlgBar?.visibility = View.VISIBLE
            dlgBar?.progress = (done * 1000 / total).toInt()
            setDlg("⬇ ${mb} / ${total / 1048576} MB — أبقِ الشاشة مفتوحة")
        } else {
            setDlg("⬇ ${mb} MB")
        }
    }

    private fun modelReady(f: File?, err: String?) {
        downloading = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        dlgBar?.visibility = View.GONE
        if (f == null) {
            setDlg("⚠ فشل: ${err}")
            addAssistant("فشل تنزيل أو استيراد النموذج: ${err}")
        } else {
            prefs.edit().putString("model_path", f.path).apply()
            setDlg("✅ تم: ${f.name}")
            loadModelIfAny()
        }
    }

    private fun showSetup() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(12), dp(20), dp(4))

        val st = TextView(this)
        st.textSize = 14f
        st.setTextColor(Color.parseColor("#CBD5E1"))
        val path = prefs.getString("model_path", null)
        st.text = if (path != null && File(path).exists()) "النموذج الحالي: ${File(path).name}" else "لا يوجد نموذج بعد."
        dlgStatus = st
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 1000
        bar.visibility = View.GONE
        dlgBar = bar

        val btnDl = Button(this)
        btnDl.isAllCaps = false
        btnDl.text = "⬇ تنزيل النموذج الموصى به\nGemma 4 E2B (≈ 2.6 GB، مرة واحدة)"
        btnDl.setOnClickListener {
            if (downloading) return@setOnClickListener
            downloading = true
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            setDlg("⏳ جارٍ الاتصال…")
            ModelStore.download(applicationContext, ModelStore.DEFAULT_URL,
                { d, t -> runOnUiThread { progress(d, t) } },
                { f, err -> runOnUiThread { modelReady(f, err) } })
        }
        val btnPick = Button(this)
        btnPick.isAllCaps = false
        btnPick.text = "📁 استيراد ملف نموذج (.litertlm) من الهاتف"
        btnPick.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            startActivityForResult(i, REQ_PICK)
        }
        val swGpu = Switch(this)
        swGpu.text = "استخدام GPU (أسرع، وقد لا يعمل على بعض الهواتف)"
        swGpu.setTextColor(Color.parseColor("#CBD5E1"))
        swGpu.isChecked = prefs.getBoolean("gpu", false)
        val swVis = Switch(this)
        swVis.text = "النموذج يدعم الصور (للكاميرا)"
        swVis.setTextColor(Color.parseColor("#CBD5E1"))
        swVis.isChecked = prefs.getBoolean("vision", true)

        col.addView(st)
        col.addView(bar)
        col.addView(btnDl)
        col.addView(btnPick)
        col.addView(swGpu)
        col.addView(swVis)

        val sv = ScrollView(this)
        sv.addView(col)
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("⚙ الإعدادات")
            .setView(sv)
            .setPositiveButton("حفظ وإعادة تحميل") { _, _ ->
                prefs.edit().putBoolean("gpu", swGpu.isChecked).putBoolean("vision", swVis.isChecked).apply()
                loadModelIfAny()
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun loadModelIfAny() {
        val p = prefs.getString("model_path", null)
        val f = if (p != null) File(p) else null
        if (f == null || !f.exists()) {
            setStatus("⚠ لا يوجد نموذج — افتح ⚙")
            return
        }
        setStatus("⏳ جارٍ تحميل النموذج…")
        llm.load(f.path, prefs.getBoolean("gpu", false), prefs.getBoolean("vision", true), assistant.systemPrompt()) { err ->
            runOnUiThread {
                if (err == null) {
                    setStatus("✅ جاهز — ${f.name}" + (if (llm.vision) " (صور)" else ""))
                } else {
                    setStatus("⚠ فشل تحميل النموذج")
                    addAssistant("تعذّر تحميل النموذج: ${err.message}")
                }
            }
        }
    }
}
