package com.jarvis.local

import android.content.Context
import org.json.JSONArray

/** Tiny on-device memory (notes the user asked Jarvis to remember). */
class Memory(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jarvis_memory", Context.MODE_PRIVATE)

    fun list(): List<String> {
        val s = sp.getString("notes", "[]") ?: "[]"
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { a.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(text: String) {
        val l = list().toMutableList()
        l.add(text.trim())
        while (l.size > 50) l.removeAt(0)
        sp.edit().putString("notes", JSONArray(l).toString()).apply()
    }

    fun clear() {
        sp.edit().putString("notes", "[]").apply()
    }
}
