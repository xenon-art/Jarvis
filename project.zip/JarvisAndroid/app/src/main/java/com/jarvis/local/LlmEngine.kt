package com.jarvis.local

import android.content.Context
import com.google.ai.edge.litertlm.*
import kotlinx.coroutines.runBlocking
import java.util.concurrent.atomic.AtomicBoolean

/** Wrapper around LiteRT-LM (Google's on-device LLM runtime). Fully offline once the model file is on the phone. */
class LlmEngine(private val ctx: Context) {
    private var engine: Engine? = null
    private var conv: Conversation? = null
    private var system: String = ""
    private var dirty = true
    private var turns = 0
    private val history = ArrayList<Pair<String, String>>()

    @Volatile
    var ready = false
        private set

    @Volatile
    var loading = false
        private set

    @Volatile
    var busy = false
        private set

    @Volatile
    var vision = false
        private set

    fun setSystem(s: String) {
        if (s != system) {
            system = s
            dirty = true
        }
    }

    fun load(path: String, useGpu: Boolean, withVision: Boolean, systemPrompt: String, done: (Throwable?) -> Unit) {
        if (loading) return
        loading = true
        ready = false
        Thread {
            var last: Throwable? = null
            // (gpu, vision) attempts, falling back to safer configurations
            val attempts = ArrayList<Pair<Boolean, Boolean>>()
            if (useGpu) attempts.add(Pair(true, withVision))
            attempts.add(Pair(false, withVision))
            if (withVision) attempts.add(Pair(false, false))
            closeInternal()
            for ((gpu, vis) in attempts) {
                try {
                    val backend: Backend = if (gpu) Backend.GPU() else Backend.CPU()
                    val cfg = if (vis) {
                        val vb: Backend = if (gpu) Backend.GPU() else Backend.CPU()
                        EngineConfig(modelPath = path, backend = backend, visionBackend = vb, cacheDir = ctx.cacheDir.path)
                    } else {
                        EngineConfig(modelPath = path, backend = backend, cacheDir = ctx.cacheDir.path)
                    }
                    val e = Engine(cfg)
                    runBlocking { e.initialize() }
                    engine = e
                    vision = vis
                    system = systemPrompt
                    dirty = true
                    ready = true
                    loading = false
                    done(null)
                    return@Thread
                } catch (t: Throwable) {
                    last = t
                }
            }
            loading = false
            done(last)
        }.start()
    }

    private fun newConversation(e: Engine): Conversation {
        val initial = ArrayList<Message>()
        for ((u, m) in history.takeLast(3)) {
            initial.add(Message.user(u))
            initial.add(Message.model(m))
        }
        val sampler = SamplerConfig(topK = 40, topP = 0.95, temperature = 0.7)
        return try {
            e.createConversation(
                ConversationConfig(
                    systemInstruction = Contents.of(system),
                    initialMessages = initial,
                    samplerConfig = sampler,
                    thinkingConfig = ThinkingConfig(enableThinking = false)
                )
            )
        } catch (t: Throwable) {
            e.createConversation(
                ConversationConfig(
                    systemInstruction = Contents.of(system),
                    initialMessages = initial,
                    samplerConfig = sampler
                )
            )
        }
    }

    fun ask(
        text: String,
        imagePath: String?,
        onChunk: (String) -> Unit,
        onFinish: (String?, Throwable?) -> Unit
    ) {
        val e = engine
        if (!ready || e == null) {
            onFinish(null, IllegalStateException("النموذج غير جاهز"))
            return
        }
        if (busy) {
            onFinish(null, IllegalStateException("النموذج مشغول"))
            return
        }
        busy = true
        Thread {
            try {
                if (conv == null || dirty || turns >= 8) {
                    try {
                        conv?.close()
                    } catch (t: Throwable) {
                    }
                    conv = newConversation(e)
                    dirty = false
                    turns = 0
                }
                val c = conv!!
                val sb = StringBuilder()
                val finished = AtomicBoolean(false)
                val cb = object : MessageCallback {
                    override fun onMessage(message: Message) {
                        sb.append(message.toString())
                        onChunk(sb.toString())
                    }

                    override fun onDone() {
                        if (finished.compareAndSet(false, true)) finish(text, sb.toString(), null, onFinish)
                    }

                    override fun onError(throwable: Throwable) {
                        if (finished.compareAndSet(false, true)) finish(text, null, throwable, onFinish)
                    }
                }
                if (imagePath != null) {
                    runBlocking {
                        c.sendMessageAsync(Contents.of(Content.ImageFile(imagePath), Content.Text(text)), cb)
                    }
                } else {
                    runBlocking { c.sendMessageAsync(text, cb) }
                }
            } catch (t: Throwable) {
                busy = false
                onFinish(null, t)
            }
        }.start()
    }

    private fun finish(user: String, reply: String?, err: Throwable?, cb: (String?, Throwable?) -> Unit) {
        busy = false
        if (reply != null) {
            turns++
            history.add(Pair(user, reply.take(600)))
            while (history.size > 8) history.removeAt(0)
        }
        cb(reply, err)
    }

    private fun closeInternal() {
        try {
            conv?.close()
        } catch (t: Throwable) {
        }
        try {
            engine?.close()
        } catch (t: Throwable) {
        }
        conv = null
        engine = null
        ready = false
    }

    fun close() = closeInternal()
}
