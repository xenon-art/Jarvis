package com.jarvis.local

import android.content.Context
import android.provider.ContactsContract

data class Contact(val name: String, val number: String)

object Contacts {
    private val MOTHER = listOf("امي", "ماما", "mama", "mom", "mum", "mother", "mommy", "الوالده", "والدتي", "يمه")
    private val FATHER = listOf("ابي", "ابوي", "بابا", "baba", "dad", "daddy", "papa", "father", "الوالد", "والدي", "ابويا")
    private val SPLIT = Regex("[^\\p{L}\\p{N}]+")

    fun all(ctx: Context): List<Contact> {
        val out = ArrayList<Contact>()
        val seen = HashSet<String>()
        try {
            val cur = ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )
            cur?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0)
                    val num = c.getString(1)
                    if (name == null || num == null) continue
                    val key = name + "|" + num.filter { it.isDigit() }
                    if (seen.add(key)) out.add(Contact(name, num))
                }
            }
        } catch (e: SecurityException) {
            // permission missing
        }
        return out
    }

    private fun variants(q: String): List<String> {
        val n = Norm(q).text.trim()
        val v = LinkedHashSet<String>()
        if (n.isNotEmpty()) v.add(n)
        for (p in listOf("الى ", "الي ", "علي ", "to ")) {
            if (n.startsWith(p) && n.length > p.length) v.add(n.substring(p.length).trim())
        }
        if (n.length > 3 && (n.startsWith("ل") || n.startsWith("ب"))) v.add(n.substring(1))
        return v.toList()
    }

    private fun score(name: String, q: String): Int {
        val keys = when {
            MOTHER.contains(q) -> MOTHER
            FATHER.contains(q) -> FATHER
            else -> listOf(q)
        }
        val nn = Norm(name).text.trim()
        val toks = nn.split(SPLIT).filter { it.isNotEmpty() }
        var best = 0
        for (k in keys) {
            val s = when {
                nn == k -> 100
                toks.contains(k) -> 90
                nn.startsWith(k) -> 80
                k.length >= 3 && nn.contains(k) -> 50
                else -> 0
            }
            if (s > best) best = s
        }
        if (best == 0) {
            val qt = q.split(SPLIT).filter { it.isNotEmpty() }
            if (qt.size > 1 && qt.all { toks.contains(it) }) best = 85
        }
        return best
    }

    /** Best matching contacts (all sharing the top score), or empty. */
    fun find(ctx: Context, query: String): List<Contact> {
        val list = all(ctx)
        for (q in variants(query)) {
            val scored = list.map { it to score(it.name, q) }.filter { it.second > 0 }
            if (scored.isNotEmpty()) {
                val top = scored.maxOf { it.second }
                return scored.filter { it.second == top }.map { it.first }
            }
        }
        return emptyList()
    }
}
