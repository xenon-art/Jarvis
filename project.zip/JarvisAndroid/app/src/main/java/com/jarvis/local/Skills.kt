package com.jarvis.local

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Result of running a skill (tool). */
sealed class Outcome {
    data class Say(val text: String) : Outcome()
    /** Sensitive action: show [prompt], run [run] only after the user confirms. */
    data class Confirm(val prompt: String, val run: () -> String) : Outcome()
    /** A missing detail: ask the user and continue with their next message. */
    data class Ask(val prompt: String, val next: (String) -> Outcome) : Outcome()
    data class Look(val question: String) : Outcome()
    data class SetLang(val lang: String) : Outcome()
    object Silence : Outcome()
}

/**
 * Phone skills (the "tools" of the agent, same idea as OpenJarvis' tool registry).
 * Anything that sends or calls requires explicit user confirmation first.
 */
class Skills(private val ctx: Context, val memory: Memory) {
    private var torch = false

    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun newTask(i: Intent): Intent = i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun run(c: ToolCall): Outcome {
        val a = c.args
        return try {
            when (c.name) {
                "send_message" -> sendMessage(a)
                "call" -> callPerson(a)
                "open_app" -> openApp(a)
                "set_alarm" -> setAlarm(a)
                "set_timer" -> setTimer(a)
                "flashlight" -> flashlight(a)
                "remember" -> {
                    val t = a.optString("text").trim()
                    if (t.isEmpty()) Outcome.Say("ماذا تريدني أن أتذكر؟")
                    else {
                        memory.add(t)
                        Outcome.Say("حسنًا، سأتذكر ذلك.")
                    }
                }
                "recall" -> {
                    val l = memory.list()
                    if (l.isEmpty()) Outcome.Say("لا أحتفظ بأي ملاحظات بعد.")
                    else Outcome.Say("أتذكر: " + l.takeLast(10).joinToString("، "))
                }
                "forget" -> {
                    memory.clear()
                    Outcome.Say("مسحت كل الملاحظات.")
                }
                "battery" -> battery()
                "time" -> timeInfo(a.optString("kind", "both"))
                "calc" -> {
                    try {
                        Outcome.Say("الناتج ${Calc.fmt(Calc.eval(a.optString("expr")))}")
                    } catch (e: Exception) {
                        Outcome.Say("لم أستطع حساب ذلك.")
                    }
                }
                "look" -> Outcome.Look(a.optString("question"))
                "set_lang" -> Outcome.SetLang(a.optString("lang", "ar"))
                "stop" -> Outcome.Silence
                else -> Outcome.Say("لا أعرف هذه الأداة.")
            }
        } catch (e: Exception) {
            Outcome.Say("تعذّر تنفيذ الأمر: ${e.message}")
        }
    }

    // ---------------- messages ----------------
    private fun sendMessage(a: JSONObject): Outcome {
        val channel = a.optString("channel", "sms")
        val to = a.optString("to").trim()
        var text = a.optString("text").trim()
        val raw = a.optString("raw").trim()

        if (to.isEmpty() && raw.isEmpty()) {
            return Outcome.Ask("لمن أرسل الرسالة؟") { who ->
                sendMessage(JSONObject().put("channel", channel).put("to", who))
            }
        }
        if (!has(Manifest.permission.READ_CONTACTS)) {
            return Outcome.Say("أحتاج صلاحية جهات الاتصال لأعرف رقم الشخص. فعّلها من إعدادات التطبيق.")
        }

        var contact: Contact? = null
        if (to.isNotEmpty()) {
            contact = Contacts.find(ctx, to).firstOrNull()
            if (contact == null) return Outcome.Say("لم أجد \"${to}\" في جهات الاتصال.")
        } else {
            val toks = raw.split(Regex("\\s+")).filter { it.isNotEmpty() }
            for (k in minOf(3, toks.size) downTo 1) {
                val cand = toks.take(k).joinToString(" ")
                val f = Contacts.find(ctx, cand)
                if (f.isNotEmpty()) {
                    contact = f[0]
                    text = toks.drop(k).joinToString(" ")
                    break
                }
            }
            if (contact == null) {
                return Outcome.Say("لم أفهم لمن أرسل. قل مثلًا: أرسل لأمي رسالة تقول وصلت بالسلامة.")
            }
        }
        val c: Contact = contact ?: return Outcome.Say("لم أجد جهة الاتصال.")
        if (text.isEmpty()) {
            return Outcome.Ask("ماذا تريد أن أكتب لـ ${c.name}؟") { body -> confirmSend(channel, c, body.trim()) }
        }
        return confirmSend(channel, c, text)
    }

    private fun confirmSend(channel: String, c: Contact, text: String): Outcome {
        if (text.isEmpty()) return Outcome.Say("الرسالة فارغة، ألغيت الإرسال.")
        return if (channel == "whatsapp") {
            Outcome.Confirm("سأفتح واتساب لمحادثة ${c.name} (${c.number}) وأكتب فيها:\n«${text}»\nأكمل؟") { openWhatsapp(c, text) }
        } else {
            Outcome.Confirm("سأرسل رسالة SMS إلى ${c.name} (${c.number}):\n«${text}»\nهل أرسلها؟") { sendSms(c, text) }
        }
    }

    private fun sendSms(c: Contact, text: String): String {
        if (!has(Manifest.permission.SEND_SMS)) return "لا أملك صلاحية إرسال الرسائل. فعّلها من إعدادات التطبيق."
        return try {
            val sm = ctx.getSystemService(SmsManager::class.java)
            val parts = sm.divideMessage(text)
            if (parts.size > 1) sm.sendMultipartTextMessage(c.number, null, parts, null, null)
            else sm.sendTextMessage(c.number, null, text, null, null)
            "تم إرسال الرسالة إلى ${c.name}."
        } catch (e: Exception) {
            "تعذّر الإرسال: ${e.message}"
        }
    }

    private val CC = mapOf(
        "SA" to "966", "AE" to "971", "EG" to "20", "KW" to "965", "QA" to "974", "BH" to "973",
        "OM" to "968", "JO" to "962", "IQ" to "964", "YE" to "967", "SY" to "963", "LB" to "961",
        "PS" to "970", "MA" to "212", "DZ" to "213", "TN" to "216", "LY" to "218", "SD" to "249",
        "US" to "1", "GB" to "44", "TR" to "90"
    )

    private fun waNumber(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        if (raw.trim().startsWith("+")) return digits
        if (digits.startsWith("00")) return digits.substring(2)
        if (digits.startsWith("0")) {
            val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val iso = tm.simCountryIso.uppercase(Locale.ROOT)
            val cc = CC[iso] ?: return digits.substring(1)
            return cc + digits.substring(1)
        }
        return digits
    }

    private fun openWhatsapp(c: Contact, text: String): String {
        val uri = Uri.parse("https://wa.me/" + waNumber(c.number) + "?text=" + Uri.encode(text))
        return try {
            ctx.startActivity(newTask(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp")))
            "فتحت واتساب. اضغط زر الإرسال لإكمال الرسالة."
        } catch (e: Exception) {
            try {
                ctx.startActivity(newTask(Intent(Intent.ACTION_VIEW, uri)))
                "فتحت الرابط. اضغط إرسال لإكمال الرسالة."
            } catch (e2: Exception) {
                "واتساب غير مثبّت على الهاتف."
            }
        }
    }

    // ---------------- calls ----------------
    private fun callPerson(a: JSONObject): Outcome {
        val to = a.optString("to").trim()
        if (to.isEmpty()) return Outcome.Ask("بمن أتصل؟") { who -> callPerson(JSONObject().put("to", who)) }
        if (!has(Manifest.permission.READ_CONTACTS)) return Outcome.Say("أحتاج صلاحية جهات الاتصال.")
        val c = Contacts.find(ctx, to).firstOrNull() ?: return Outcome.Say("لم أجد \"${to}\" في جهات الاتصال.")
        return Outcome.Confirm("هل أتصل بـ ${c.name} على الرقم ${c.number}؟") { doCall(c) }
    }

    private fun doCall(c: Contact): String {
        return try {
            val perm = has(Manifest.permission.CALL_PHONE)
            val i = Intent(if (perm) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.fromParts("tel", c.number, null))
            ctx.startActivity(newTask(i))
            if (perm) "أتصل بـ ${c.name} الآن." else "فتحت لوحة الاتصال برقم ${c.name}."
        } catch (e: Exception) {
            "تعذّر الاتصال: ${e.message}"
        }
    }

    // ---------------- apps ----------------
    private val ALIASES = listOf(
        "واتساب" to "whatsapp", "واتس" to "whatsapp", "يوتيوب" to "youtube", "كاميره" to "camera",
        "اعدادات" to "settings", "خرائط" to "maps", "جوجل" to "google", "قوقل" to "google",
        "تلجرام" to "telegram", "تيليجرام" to "telegram", "انستقرام" to "instagram", "انستغرام" to "instagram",
        "انستا" to "instagram", "تويتر" to "twitter", "سناب" to "snapchat", "تيك توك" to "tiktok",
        "هاتف" to "phone", "رسايل" to "messages", "ساعه" to "clock", "حاسبه" to "calculator",
        "معرض" to "gallery", "صور" to "photos", "كروم" to "chrome", "ملفات" to "files",
        "جهات" to "contacts", "جيميل" to "gmail", "تقويم" to "calendar", "موسيقي" to "music"
    )

    private fun openApp(a: JSONObject): Outcome {
        val name = a.optString("name")
        val q0 = Norm(name).text.trim()
        if (q0.isEmpty()) return Outcome.Say("أي تطبيق تريد أن أفتح؟")
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val targets = ALIASES.filter { q0.contains(it.first) }.map { it.second }
        var bestPkg: String? = null
        var bestName = ""
        var bestScore = 0
        for (ri in apps) {
            val label = ri.loadLabel(pm).toString()
            val nl = Norm(label).text.trim()
            var s = 0
            if (nl == q0) s = 100
            else if (q0.length >= 2 && nl.contains(q0)) s = 80
            else if (nl.length >= 3 && q0.contains(nl)) s = 70
            else if (targets.any { nl.contains(it) }) s = 75
            if (s > bestScore) {
                bestScore = s
                bestPkg = ri.activityInfo.packageName
                bestName = label
            }
        }
        val pkg = bestPkg ?: return Outcome.Say("لم أجد تطبيقًا باسم ${name}.")
        val li = pm.getLaunchIntentForPackage(pkg) ?: return Outcome.Say("تعذّر فتح ${bestName}.")
        ctx.startActivity(newTask(li))
        return Outcome.Say("فتحت ${bestName}.")
    }

    // ---------------- alarm / timer ----------------
    private fun fmt12(h: Int, m: Int): String {
        val h12 = if (h % 12 == 0) 12 else h % 12
        val period = if (h < 12) "صباحًا" else "مساءً"
        return "${h12}:${String.format(Locale.US, "%02d", m)} ${period}"
    }

    private fun setAlarm(a: JSONObject): Outcome {
        val h = a.optInt("hour", -1)
        val m = a.optInt("minute", 0)
        if (h !in 0..23 || m !in 0..59) return Outcome.Say("لم أفهم وقت المنبه.")
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return try {
            ctx.startActivity(newTask(i))
            Outcome.Say("ضبطت المنبه على ${fmt12(h, m)}.")
        } catch (e: Exception) {
            Outcome.Say("تعذّر ضبط المنبه.")
        }
    }

    private fun human(sec: Int): String {
        if (sec % 3600 == 0) return "${sec / 3600} ساعة"
        if (sec >= 3600) return "${sec / 3600} ساعة و${(sec % 3600) / 60} دقيقة"
        if (sec % 60 == 0) return "${sec / 60} دقيقة"
        if (sec > 60) return "${sec / 60} دقيقة و${sec % 60} ثانية"
        return "${sec} ثانية"
    }

    private fun setTimer(a: JSONObject): Outcome {
        val s = a.optInt("seconds", 0)
        if (s <= 0) return Outcome.Say("لم أفهم مدة المؤقت.")
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, s)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return try {
            ctx.startActivity(newTask(i))
            Outcome.Say("ضبطت مؤقتًا لمدة ${human(s)}.")
        } catch (e: Exception) {
            Outcome.Say("تعذّر ضبط المؤقت.")
        }
    }

    // ---------------- device ----------------
    private fun flashlight(a: JSONObject): Outcome {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return Outcome.Say("لا يوجد فلاش في هذا الهاتف.")
        val on = if (a.has("on")) a.optBoolean("on") else !torch
        return try {
            cm.setTorchMode(id, on)
            torch = on
            Outcome.Say(if (on) "أضأت الكشاف." else "أطفأت الكشاف.")
        } catch (e: Exception) {
            Outcome.Say("تعذّر تشغيل الكشاف.")
        }
    }

    private fun battery(): Outcome {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val st = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = st?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return Outcome.Say("البطارية ${pct} بالمئة" + (if (charging) " وهي تشحن." else "."))
    }

    private fun timeInfo(kind: String): Outcome {
        val now = Date()
        val loc = Locale.forLanguageTag("ar")
        val time = SimpleDateFormat("h:mm a", loc).format(now)
        val date = SimpleDateFormat("EEEE d MMMM yyyy", loc).format(now)
        return Outcome.Say(
            when (kind) {
                "time" -> "الساعة الآن ${time}."
                "date" -> "اليوم ${date}."
                else -> "الساعة ${time}، واليوم ${date}."
            }
        )
    }
}
