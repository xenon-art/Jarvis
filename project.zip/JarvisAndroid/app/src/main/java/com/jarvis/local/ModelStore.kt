package com.jarvis.local

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Downloads (once, with resume) or imports the model file. After that the assistant works fully offline. */
object ModelStore {
    const val DEFAULT_URL =
        "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm"

    fun dir(ctx: Context): File = File(ctx.filesDir, "models").also { it.mkdirs() }

    fun download(ctx: Context, url: String, onProgress: (Long, Long) -> Unit, onDone: (File?, String?) -> Unit) {
        Thread {
            try {
                val name = url.substringAfterLast('/').substringBefore('?')
                val out = File(dir(ctx), name)
                if (out.exists() && out.length() > 100_000_000L) {
                    onDone(out, null)
                    return@Thread
                }
                val part = File(dir(ctx), "${name}.part")
                var have = if (part.exists()) part.length() else 0L
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 20000
                conn.readTimeout = 30000
                conn.instanceFollowRedirects = true
                if (have > 0) conn.setRequestProperty("Range", "bytes=${have}-")
                conn.connect()
                val code = conn.responseCode
                if (code == 416) {
                    part.renameTo(out)
                    onDone(out, null)
                    return@Thread
                }
                if (code !in 200..299) {
                    onDone(null, "HTTP ${code}. إن كان النموذج يطلب تسجيل دخول فنزّله من المتصفح ثم استورده من الزر الثاني.")
                    return@Thread
                }
                val append = code == 206
                if (!append) have = 0L
                val total = have + conn.contentLengthLong
                val buf = ByteArray(256 * 1024)
                var done = have
                var last = 0L
                FileOutputStream(part, append).use { fo ->
                    conn.inputStream.use { ins ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            fo.write(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (now - last > 400) {
                                last = now
                                onProgress(done, total)
                            }
                        }
                    }
                }
                if (out.exists()) out.delete()
                part.renameTo(out)
                onDone(out, null)
            } catch (e: Exception) {
                onDone(null, e.message ?: e.toString())
            }
        }.start()
    }

    fun importUri(ctx: Context, uri: Uri, onProgress: (Long, Long) -> Unit, onDone: (File?, String?) -> Unit) {
        Thread {
            try {
                var name = "model.litertlm"
                var size = -1L
                ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) name = c.getString(ni) ?: name
                        if (si >= 0) size = c.getLong(si)
                    }
                }
                name = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val out = File(dir(ctx), name)
                val ins = ctx.contentResolver.openInputStream(uri)
                if (ins == null) {
                    onDone(null, "تعذّر قراءة الملف")
                    return@Thread
                }
                ins.use { input ->
                    FileOutputStream(out).use { fo ->
                        val buf = ByteArray(256 * 1024)
                        var done = 0L
                        var last = 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            fo.write(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (now - last > 400) {
                                last = now
                                onProgress(done, size)
                            }
                        }
                    }
                }
                onDone(out, null)
            } catch (e: Exception) {
                onDone(null, e.message ?: e.toString())
            }
        }.start()
    }
}
