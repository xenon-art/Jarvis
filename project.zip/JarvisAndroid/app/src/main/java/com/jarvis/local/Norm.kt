package com.jarvis.local

/**
 * Arabic/English text normalizer that keeps a map back to the original text,
 * so message bodies can be sent exactly as the user wrote them.
 */
class Norm(val orig: String) {
    val text: String
    private val map: IntArray

    init {
        val sb = StringBuilder()
        val idx = ArrayList<Int>()
        for (i in orig.indices) {
            val ch = orig[i].lowercaseChar()
            if (ch in '\u064B'..'\u065F' || ch == '\u0670' || ch == '\u0640') continue
            val c: Char = when (ch) {
                'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                'ى' -> 'ي'
                'ة' -> 'ه'
                'ؤ' -> 'و'
                'ئ' -> 'ي'
                in '٠'..'٩' -> '0' + (ch - '٠')
                in '۰'..'۹' -> '0' + (ch - '۰')
                '،', '؛', '؟', '!', '?', '"', '“', '”', '«', '»' -> ' '
                else -> ch
            }
            sb.append(c)
            idx.add(i)
        }
        text = sb.toString()
        map = idx.toIntArray()
    }

    /** Original substring for a [from, toExclusive) range of the normalized text. */
    fun orig(from: Int, toExclusive: Int): String {
        if (text.isEmpty()) return ""
        val a = if (from >= map.size) orig.length else map[from]
        val b = if (toExclusive >= map.size) orig.length else map[toExclusive]
        return orig.substring(a, maxOf(a, b))
    }
}
